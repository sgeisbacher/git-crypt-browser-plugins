var _a;
import { sendCommand } from './utils';
var ta = document.querySelector('#repoSecretMapping');
var saveBtn = document.querySelector('#repoSecretMappingSaveBtn');
var onSave = function () {
    var _a;
    console.log('popup-change');
    var text = (_a = ta) === null || _a === void 0 ? void 0 : _a.value;
    var cmd = { type: 'storeMapping', payload: { mapping: text || '' } };
    sendCommand(cmd).then(function (response) {
        console.log('success', response);
    });
};
(_a = saveBtn) === null || _a === void 0 ? void 0 : _a.addEventListener('click', onSave);
sendCommand({ type: 'loadMapping', payload: {} }).then(function (resp) {
    var _a;
    if (!ta || resp.type !== 'loadMapping') {
        return;
    }
    if (resp.error) {
        console.log('loadMapping error was:', resp.error);
    }
    ta.value = ((_a = resp.payload) === null || _a === void 0 ? void 0 : _a.mapping) || '';
});
//# sourceMappingURL=popup.js.map