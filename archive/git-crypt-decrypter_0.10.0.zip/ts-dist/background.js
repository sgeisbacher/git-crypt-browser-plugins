var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
import { githubTablePostProcessor } from './postProcessors';
import { isValidKey } from './utils';
console.log('starting background ...');
var getStorageValue = function () {
    return new Promise(function (res, rej) {
        chrome.storage.local.get(['mapping'], function (result) { return res(result); });
    });
};
chrome.runtime.onMessage.addListener(function (cmd, sender, sendResponse) {
    console.log('received message:', cmd.type);
    switch (cmd.type) {
        case 'decrypt':
            runDecryption(cmd)
                .then(function (cleartext) { return sendResponse({ type: 'decrypt', payload: { cleartext: cleartext } }); })
                .catch(function (e) { var _a; return sendResponse({ type: 'decrypt', error: ((_a = e) === null || _a === void 0 ? void 0 : _a.message) || e || 'unknown error' }); });
            break;
        case 'storeMapping':
            chrome.storage.local.set({ mapping: cmd.payload.mapping }, function () {
                return sendResponse({ type: 'storeMapping', payload: { success: true } });
            });
            break;
        case 'loadMapping':
            getStorageValue().then(function (obj) {
                var _a, _b;
                sendResponse({
                    type: 'loadMapping',
                    error: !((_a = obj) === null || _a === void 0 ? void 0 : _a.mapping) ? 'could load mapping' : undefined,
                    payload: { mapping: ((_b = obj) === null || _b === void 0 ? void 0 : _b.mapping) ? obj.mapping : undefined },
                });
            });
            break;
        default:
            console.log('received unknown cmd:', cmd);
    }
    return true;
});
var postProcessors = [githubTablePostProcessor];
var runDecryption = function (cmd) {
    var respBufProm = fetch(cmd.payload.rawUrl, { redirect: 'follow', headers: {} }).then(function (resp) { return resp.arrayBuffer(); });
    return Promise.all([respBufProm, getSecretForUrl(cmd.payload.rawUrl)]).then(function (_a) {
        var respBuf = _a[0], keyHex = _a[1];
        return __awaiter(void 0, void 0, void 0, function () {
            var plainText;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        if (!respBuf) {
                            throw new Error('could get raw-data');
                        }
                        if (!keyHex) {
                            throw new Error('could not find secret');
                        }
                        if (!isValidKey(keyHex)) {
                            throw new Error('key is not valid');
                        }
                        return [4 /*yield*/, decrypt(new Uint8Array(respBuf), keyHex)];
                    case 1:
                        plainText = _b.sent();
                        return [2 /*return*/, postProcessors.reduce(function (data, processor) { return processor(data); }, plainText)];
                }
            });
        });
    });
};
var getSecretForUrl = function (url) { return __awaiter(void 0, void 0, void 0, function () {
    var rawUrlRepoNameMatch, rawUrlRepoName, result, mappingStr, mapping;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                rawUrlRepoNameMatch = url.match(/https:\/\/github.com\/([a-zA-Z0-9-]+\/[a-zA-Z0-9-]+)\/([a-zA-Z0-9-]+)\/.*/);
                if (!rawUrlRepoNameMatch) {
                    throw new Error("wrong raw-url '" + url + "'");
                }
                rawUrlRepoName = rawUrlRepoNameMatch[1];
                return [4 /*yield*/, getStorageValue()];
            case 1:
                result = _a.sent();
                mappingStr = result.mapping;
                if (!mappingStr) {
                    throw new Error('no mapping found');
                }
                if (mappingStr.split('\n').some(function (line) { return line.split(':').length !== 2; })) {
                    throw new Error("wrong mapping");
                }
                mapping = mappingStr
                    .split('\n')
                    .map(function (line) { return ({ repoName: line.split(':')[0], secret: line.split(':')[1] }); })
                    .find(function (_a) {
                    var repoName = _a.repoName;
                    return repoName === rawUrlRepoName;
                });
                return [2 /*return*/, mapping ? mapping.secret : null];
        }
    });
}); };
var decrypt = function (cipherTextBytes, keyFileHexData) { return __awaiter(void 0, void 0, void 0, function () {
    var hex2ArrayBuffer, createIV, AES_KEY_START, AES_KEY_SIZE, HEADER_LEN, NONCE_LEN, keyFileBytes, header, aeskey, nonce, ciphertext, iv, key, decrypted;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                hex2ArrayBuffer = function (hex) {
                    return new Uint8Array((hex.match(/[\da-f]{2}/gi) || []).map(function (h) { return parseInt(h, 16); }));
                };
                createIV = function (nonce) { return new Uint8Array(16).map(function (v, i) { return nonce[i] || 0; }); };
                AES_KEY_START = 40;
                AES_KEY_SIZE = 32;
                HEADER_LEN = 10;
                NONCE_LEN = 12;
                keyFileBytes = hex2ArrayBuffer(keyFileHexData);
                header = new TextDecoder().decode(cipherTextBytes.slice(0, HEADER_LEN));
                aeskey = keyFileBytes.slice(AES_KEY_START, AES_KEY_START + AES_KEY_SIZE);
                nonce = cipherTextBytes.slice(HEADER_LEN, HEADER_LEN + NONCE_LEN);
                ciphertext = cipherTextBytes.slice(HEADER_LEN + NONCE_LEN);
                iv = createIV(nonce);
                if (header.indexOf('GITCRYPT') < 0) {
                    throw new Error("file isn't encrypted with GITCRYPT but was '" + header + "'");
                }
                return [4 /*yield*/, window.crypto.subtle.importKey('raw', aeskey, 'AES-CTR', false, ['encrypt', 'decrypt'])];
            case 1:
                key = _a.sent();
                return [4 /*yield*/, window.crypto.subtle.decrypt({
                        name: 'AES-CTR',
                        counter: iv,
                        length: 32,
                    }, key, ciphertext)];
            case 2:
                decrypted = _a.sent();
                return [2 /*return*/, new TextDecoder().decode(decrypted)];
        }
    });
}); };
//# sourceMappingURL=background.js.map