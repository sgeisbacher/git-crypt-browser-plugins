import { debounce } from 'lodash';
import { sendCommand } from './utils';
var injectCode = function () {
    var _a;
    if (document.querySelector('#degitcryptbtn')) {
        // already injected, skipping ...
        return;
    }
    var rawUrlBtn = document.querySelector('#raw-url');
    var btnGroup = (_a = rawUrlBtn) === null || _a === void 0 ? void 0 : _a.parentElement;
    if (!rawUrlBtn || !btnGroup) {
        // btn-group not found, skipping ...
        return;
    }
    var decryptBtn = document.createElement('button');
    decryptBtn.setAttribute('id', 'degitcryptbtn');
    decryptBtn.setAttribute('class', 'btn btn-sm BtnGroup-item');
    decryptBtn.textContent = 'de-git-crypt it';
    decryptBtn.addEventListener('click', onDecryptClick);
    btnGroup.insertBefore(decryptBtn, rawUrlBtn);
};
var createErrorField = function (errMsg) {
    var span = document.createElement('span');
    span.setAttribute('class', 'degitcrypter-error');
    span.setAttribute('style', 'display: block; background: #f2dede; border-color: #ebccd1; padding: 15px; color: #a94442; border-radius: 4px; margin-bottom: 10px;'); // in parent -> border: 1px solid transparent;
    span.textContent = "git-crypt-decrypter: " + errMsg;
    return span;
};
var clearErrors = function () { return Array.from(document.querySelectorAll('.degitcrypter-error')).forEach(function (el) { return el.remove(); }); };
var onDecryptClick = function () {
    clearErrors();
    var rawUrl = Array.from(document.querySelectorAll('div.Box-body a'))
        .map(function (link) { return link.href; })
        .find(function (href) { return (href || '').endsWith('?raw=true'); });
    if (rawUrl) {
        var cmd = { type: 'decrypt', payload: { rawUrl: rawUrl } };
        sendCommand(cmd).then(function (resp) {
            var _a, _b, _c;
            var div = document.querySelector('div[itemprop=text]');
            if (((_a = resp) === null || _a === void 0 ? void 0 : _a.type) !== 'decrypt') {
                return;
            }
            if (resp.error) {
                if (div) {
                    div.insertBefore(createErrorField(resp.error), div.firstChild);
                    return;
                }
            }
            if (div && ((_c = (_b = resp) === null || _b === void 0 ? void 0 : _b.payload) === null || _c === void 0 ? void 0 : _c.cleartext)) {
                // div.textContent = resp.payload.cleartext;
                div.innerHTML = resp.payload.cleartext;
                return;
            }
            // nothing to do ...
        });
    }
};
chrome.runtime.onMessage.addListener(function (cmd, sender, sendResponse) {
    switch (cmd.type) {
    }
    return true;
});
document.addEventListener('DOMNodeInserted', debounce(injectCode, 2000));
injectCode();
//# sourceMappingURL=content.js.map