export var lineBreakToHtmlPostProcessor = function (data) {
    return data.split('\n').join('<br/>');
};
export var githubTablePostProcessor = function (data) {
    var body = data
        .split('\n')
        .map(function (line, index) { return "<tr>\n                <td id=\"L" + (index + 1) + "\" class=\"blob-num js-line-number\" data-line-number=\"" + (index + 1) + "\"></td>\n                <td id=\"LC" + (index + 1) + "\" class=\"blob-code blob-code-inner js-file-line\">" + line + "</td>\n            </tr>"; })
        .join('');
    return "<table class=\"highlight tab-size js-file-line-container\" data-tab-size=\"8\" data-paste-markdown-skip=\"\"><tbody>" + body + "</tbody></table>";
};
//# sourceMappingURL=postProcessors.js.map